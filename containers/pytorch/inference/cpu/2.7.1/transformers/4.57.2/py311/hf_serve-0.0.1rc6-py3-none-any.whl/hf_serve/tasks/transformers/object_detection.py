from typing import List, Optional, Union

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from hf_serve.serde import Image
from hf_serve.tasks.predictor import Predictor
from hf_serve.types import FileForm, FloatForm


class ObjectDetectionParameters(BaseModel):
    threshold: Optional[float] = None


class ObjectDetectionInput(BaseModel):
    inputs: Union[str, bytes] = Field(validation_alias=AliasChoices("inputs", "image"))
    parameters: Optional[ObjectDetectionParameters] = None

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "inputs": "https://huggingface.co/datasets/Narsil/image_dummy/raw/main/parrots.png",
                    "parameters": {
                        "threshold": 0.9,
                    },
                }
            ]
        },
    )


class ObjectDetectionFormInput(BaseModel):
    file: FileForm
    threshold: Optional[FloatForm] = None

    model_config = ConfigDict(extra="forbid")


class BoundingBox(BaseModel):
    xmin: float
    ymin: float
    xmax: float
    ymax: float


class ObjectDetectionOutputValue(BaseModel):
    label: str
    score: float
    box: BoundingBox


class ObjectDetectionOutput(BaseModel):
    results: List[ObjectDetectionOutputValue]


class ObjectDetection(Predictor[ObjectDetectionInput, ObjectDetectionOutput]):
    def __init__(self, model_id: str, dtype: Optional[str] = None, device: str = "auto") -> None:
        super().__init__()

        import torch
        from transformers import pipeline
        from transformers.pipelines.object_detection import ObjectDetectionPipeline

        # NOTE: Apparently some (not all) models don't support the `device_map=auto` so we should probably
        # either add a check or just default to CUDA instead
        if device == "auto":
            # e.g. DistilBertForSequenceClassification won't support it
            device = "cuda" if torch.cuda.is_available() else "mps" if torch.mps.is_available() else "cpu"

        self.pipeline: ObjectDetectionPipeline = pipeline(
            task="object-detection",
            model=model_id,
            dtype=getattr(torch, dtype) if dtype is not None else "auto",
            device=device,
        )

        if torch.mps.is_available():
            torch.mps.empty_cache()
            torch.mps.set_per_process_memory_fraction(0.9)

    def __call__(self, payload: ObjectDetectionInput) -> ObjectDetectionOutput:
        parameters = {}
        if payload.parameters:
            parameters = payload.parameters.model_dump(exclude_none=True)

        results = self.pipeline(Image.deserialize(payload.inputs), **parameters)
        return ObjectDetectionOutput(results=results)  # type: ignore
