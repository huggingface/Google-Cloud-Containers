"""`CustomPredictor` for ...

References:
    - https://github.com/HiDream-ai/HiDream-I1/blob/main/inference.py
"""
